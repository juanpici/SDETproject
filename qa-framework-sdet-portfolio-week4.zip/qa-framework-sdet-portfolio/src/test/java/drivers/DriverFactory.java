package drivers;

import com.microsoft.playwright.*;
import config.TestConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class DriverFactory {
  private static final Logger log = LoggerFactory.getLogger(DriverFactory.class);

  private static Playwright playwright;
  private static Browser browser;

  private static final ThreadLocal<BrowserContext> CTX = new ThreadLocal<>();
  private static final ThreadLocal<Page> PAGE = new ThreadLocal<>();

  private DriverFactory() {}

  public static synchronized void initOnce() {
    if (playwright != null && browser != null) return;
    TestConfig.load();

    playwright = Playwright.create();

    BrowserType browserType = playwright.chromium();
    String requested = TestConfig.browser().toLowerCase();
    if (requested.contains("firefox")) browserType = playwright.firefox();
    if (requested.contains("webkit")) browserType = playwright.webkit();

    browser = browserType.launch(new BrowserType.LaunchOptions().setHeadless(TestConfig.headless()));

    Runtime.getRuntime().addShutdownHook(new Thread(() -> {
      try { closeAll(); } catch (Exception ignored) {}
    }));

    log.info("Playwright initialized. Browser={}, headless={}", requested, TestConfig.headless());
  }

  public static void createScenarioContext() {
    initOnce();

    BrowserContext context = browser.newContext(new Browser.NewContextOptions());
    context.setDefaultTimeout(TestConfig.timeoutMs());
    context.setDefaultNavigationTimeout(TestConfig.timeoutMs());

    // Start tracing for richer debugging (saved on failure)
    context.tracing().start(new Tracing.StartOptions()
        .setScreenshots(true)
        .setSnapshots(true)
        .setSources(true));

    Page page = context.newPage();

    CTX.set(context);
    PAGE.set(page);
  }

  public static BrowserContext context() {
    BrowserContext c = CTX.get();
    if (c == null) throw new IllegalStateException("Context not initialized for this thread. Did you call createScenarioContext()?");
    return c;
  }

  public static Page page() {
    Page p = PAGE.get();
    if (p == null) throw new IllegalStateException("Page not initialized for this thread. Did you call createScenarioContext()?");
    return p;
  }

  public static void closeScenarioContext() {
    try {
      Page p = PAGE.get();
      if (p != null) p.close();
    } finally {
      PAGE.remove();
    }

    try {
      BrowserContext c = CTX.get();
      if (c != null) c.close();
    } finally {
      CTX.remove();
    }
  }

  public static synchronized void closeAll() {
    if (browser != null) { browser.close(); browser = null; }
    if (playwright != null) { playwright.close(); playwright = null; }
    log.info("Playwright closed.");
  }
}
