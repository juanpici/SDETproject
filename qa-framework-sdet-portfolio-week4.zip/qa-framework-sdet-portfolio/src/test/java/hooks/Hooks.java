package hooks;

import com.microsoft.playwright.Page;
import com.microsoft.playwright.Tracing;
import drivers.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utils.EvidenceUtils;

import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.Files;
import java.nio.file.StandardOpenOption;
import java.time.Instant;

public class Hooks {

  private static final ThreadLocal<Long> START_MS = new ThreadLocal<>();
  private static final Object METRICS_LOCK = new Object();

  @Before
  public void beforeScenario() {
    START_MS.set(System.currentTimeMillis());
    DriverFactory.createScenarioContext();
  }

  @After
  public void afterScenario(Scenario scenario) {
    try {
      if (scenario.isFailed()) {
        Page page = DriverFactory.page();
        Path dir = EvidenceUtils.evidenceDir(scenario.getName());

        // Screenshot
        page.screenshot(new Page.ScreenshotOptions()
            .setPath(dir.resolve("failure.png"))
            .setFullPage(true));

        // Optional: page source
        try {
          Files.writeString(dir.resolve("page.html"), page.content());
        } catch (Exception ignored) {}

        // Save trace.zip
        try {
          DriverFactory.context().tracing().stop(new Tracing.StopOptions().setPath(dir.resolve("trace.zip")));
        } catch (Exception ignored) {}

      } else {
        // Stop tracing without saving when scenario passes
        try { DriverFactory.context().tracing().stop(); } catch (Exception ignored) {}
      }

      // Metrics CSV
      Long start = START_MS.get();
      long duration = (start == null) ? -1 : (System.currentTimeMillis() - start);
      appendMetrics(scenario.getName(), scenario.isFailed() ? "FAILED" : "PASSED", duration);

    } finally {
      START_MS.remove();
      DriverFactory.closeScenarioContext();
    }
  }

  private static void appendMetrics(String scenarioName, String status, long durationMs) {
    Path metricsDir = Paths.get("target", "metrics");
    Path csv = metricsDir.resolve("scenario_times.csv");
    String safeName = EvidenceUtils.sanitizeName(scenarioName);
    String line = String.format("%s,%s,%d,%s%n", safeName, status, durationMs, Instant.now());

    synchronized (METRICS_LOCK) {
      try {
        Files.createDirectories(metricsDir);
        if (!Files.exists(csv)) {
          Files.writeString(csv, "scenario,status,durationMs,timestamp\n", StandardOpenOption.CREATE);
        }
        Files.writeString(csv, line, StandardOpenOption.APPEND);
      } catch (Exception ignored) {}
    }
  }
}
