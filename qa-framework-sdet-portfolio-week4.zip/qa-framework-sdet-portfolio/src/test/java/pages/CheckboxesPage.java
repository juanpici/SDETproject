package pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class CheckboxesPage {
  private final Page page;
  private final Locator checkbox1;
  private final Locator checkbox2;

  public CheckboxesPage(Page page) {
    this.page = page;
    this.checkbox1 = page.locator("#checkboxes input").nth(0);
    this.checkbox2 = page.locator("#checkboxes input").nth(1);
  }

  public void open(String baseUrl) {
    page.navigate(baseUrl + "/checkboxes");
    assertThat(checkbox1).isVisible();
  }

  public void setCheckbox1(boolean checked) {
    if (checkbox1.isChecked() != checked) checkbox1.click();
  }

  public void assertCheckbox1(boolean checked) {
    if (checked) assertThat(checkbox1).isChecked();
    else assertThat(checkbox1).not().isChecked();
  }
}
