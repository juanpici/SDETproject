package pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class LoginPage {
  private final Page page;
  private final Locator username;
  private final Locator password;
  private final Locator loginButton;
  private final Locator flash;

  public LoginPage(Page page) {
    this.page = page;
    this.username = page.locator("#username");
    this.password = page.locator("#password");
    this.loginButton = page.locator("button[type='submit']");
    this.flash = page.locator("#flash");
  }

  public void open(String baseUrl) {
    page.navigate(baseUrl + "/login");
    assertThat(username).isVisible();
  }

  public void login(String user, String pass) {
    username.fill(user);
    password.fill(pass);
    loginButton.click();
  }

  public String flashMessage() {
    return flash.innerText();
  }
}
