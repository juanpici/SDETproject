package pages;

import com.microsoft.playwright.Locator;
import com.microsoft.playwright.Page;

import java.util.regex.Pattern;

import static com.microsoft.playwright.assertions.PlaywrightAssertions.assertThat;

public class SecureAreaPage {
  private final Page page;
  private final Locator flash;
  private final Locator logout;

  public SecureAreaPage(Page page) {
    this.page = page;
    this.flash = page.locator("#flash");
    this.logout = page.locator("a.button.secondary.radius");
  }

  public void assertLoggedIn() {
    assertThat(page).hasURL(Pattern.compile(".*\\/secure"));
    assertThat(flash).containsText("You logged into a secure area!");
  }

  public void logout() {
    logout.click();
  }

  public void assertLoggedOut() {
    assertThat(page).hasURL(Pattern.compile(".*\\/login"));
    assertThat(flash).containsText("You logged out of the secure area!");
  }
}
