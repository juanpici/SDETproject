package config;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public final class TestConfig {
  private static final String DEFAULT_ENV = "qa";
  private static final Properties PROPS = new Properties();
  private static boolean loaded = false;

  private TestConfig() {}

  public static synchronized void load() {
    if (loaded) return;
    String env = System.getProperty("env", DEFAULT_ENV).trim();
    String resource = String.format("environments/%s.properties", env);

    try (InputStream is = TestConfig.class.getClassLoader().getResourceAsStream(resource)) {
      if (is == null) throw new IllegalStateException("Environment properties not found: " + resource);
      PROPS.load(is);
      loaded = true;
    } catch (IOException e) {
      throw new RuntimeException("Failed to load config: " + resource, e);
    }
  }

  private static String get(String key) {
    load();
    String val = PROPS.getProperty(key);
    if (val == null || val.isBlank()) throw new IllegalStateException("Missing config key: " + key);
    return val.trim();
  }

  public static String baseUrl() { return get("baseUrl"); }
  public static String apiBaseUrl() { return get("apiBaseUrl"); }
  public static boolean headless() { return Boolean.parseBoolean(get("headless")); }
  public static String browser() { return get("browser"); }
  public static int timeoutMs() { return Integer.parseInt(get("timeoutMs")); }
}
