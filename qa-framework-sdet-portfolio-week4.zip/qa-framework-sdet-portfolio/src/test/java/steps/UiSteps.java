package steps;

import config.TestConfig;
import drivers.DriverFactory;
import io.cucumber.java.en.*;
import pages.CheckboxesPage;
import pages.LoginPage;
import pages.SecureAreaPage;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class UiSteps {

  private LoginPage login() { return new LoginPage(DriverFactory.page()); }
  private SecureAreaPage secure() { return new SecureAreaPage(DriverFactory.page()); }
  private CheckboxesPage checkboxes() { return new CheckboxesPage(DriverFactory.page()); }

  @Given("I open the login page")
  public void iOpenTheLoginPage() {
    login().open(TestConfig.baseUrl());
  }

  @When("I login with username {string} and password {string}")
  public void iLoginWithUsernameAndPassword(String user, String pass) {
    login().login(user, pass);
  }

  @Then("I should be logged in")
  public void iShouldBeLoggedIn() {
    secure().assertLoggedIn();
  }

  @Then("I should see a login error")
  public void iShouldSeeALoginError() {
    String msg = login().flashMessage();
    assertTrue(msg.contains("Your username is invalid!") || msg.contains("Your password is invalid!"),
        "Expected invalid credentials message but got: " + msg);
  }

  @When("I logout")
  public void iLogout() {
    secure().logout();
  }

  @Then("I should be logged out")
  public void iShouldBeLoggedOut() {
    secure().assertLoggedOut();
  }

  @Given("I open the checkboxes page")
  public void iOpenTheCheckboxesPage() {
    checkboxes().open(TestConfig.baseUrl());
  }

  @When("I set checkbox 1 to {string}")
  public void iSetCheckbox1To(String state) {
    boolean checked = state.equalsIgnoreCase("checked");
    checkboxes().setCheckbox1(checked);
  }

  @Then("checkbox 1 should be {string}")
  public void checkbox1ShouldBe(String state) {
    boolean checked = state.equalsIgnoreCase("checked");
    checkboxes().assertCheckbox1(checked);
  }
}
