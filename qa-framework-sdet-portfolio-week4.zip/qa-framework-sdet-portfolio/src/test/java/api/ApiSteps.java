package api;

import io.cucumber.java.en.*;
import io.restassured.response.Response;

import java.util.HashMap;
import java.util.Map;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.junit.jupiter.api.Assertions.*;

public class ApiSteps {
  private final ReqresClient client = new ReqresClient();
  private Response lastResponse;

  @When("I request the users list for page {int}")
  public void iRequestTheUsersListForPage(Integer page) {
    lastResponse = client.listUsers(page);
  }

  @When("I request user with id {int}")
  public void iRequestUserWithId(Integer id) {
    lastResponse = client.getUser(id);
  }

  @When("I login via API with email {string} and password {string}")
  public void iLoginViaApiWithEmailAndPassword(String email, String password) {
    Map<String, Object> payload = new HashMap<>();
    if (!email.isBlank()) payload.put("email", email);
    if (!password.isBlank()) payload.put("password", password);
    lastResponse = client.login(payload);
  }

  @Then("the response status should be {int}")
  public void theResponseStatusShouldBe(Integer status) {
    assertNotNull(lastResponse, "No response captured");
    assertEquals(status.intValue(), lastResponse.statusCode());
  }

  @Then("the response should contain field {string}")
  public void theResponseShouldContainField(String fieldPath) {
    assertNotNull(lastResponse, "No response captured");
    Object value = lastResponse.jsonPath().get(fieldPath);
    assertNotNull(value, "Expected JSON path to exist: " + fieldPath);
  }

  @Then("the response should contain non-empty token")
  public void theResponseShouldContainNonEmptyToken() {
    String token = lastResponse.jsonPath().getString("token");
    assertNotNull(token);
    assertFalse(token.isBlank());
  }

  @Then("the response should match schema {string}")
  public void theResponseShouldMatchSchema(String schemaFile) {
    assertNotNull(lastResponse, "No response captured");
    lastResponse.then().assertThat().body(matchesJsonSchemaInClasspath("schemas/" + schemaFile));
  }
}
