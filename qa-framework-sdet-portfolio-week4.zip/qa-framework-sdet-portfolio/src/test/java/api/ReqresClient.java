package api;

import config.TestConfig;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

import java.util.Map;

import static io.restassured.RestAssured.given;

public class ReqresClient {

  public ReqresClient() {
    TestConfig.load();
    RestAssured.baseURI = TestConfig.apiBaseUrl();
  }

  public Response listUsers(int page) {
    return given().when().get("/api/users?page=" + page).then().extract().response();
  }

  public Response getUser(int id) {
    return given().when().get("/api/users/" + id).then().extract().response();
  }

  public Response login(Map<String, Object> payload) {
    return given()
        .contentType(ContentType.JSON)
        .body(payload)
        .when()
        .post("/api/login")
        .then()
        .extract()
        .response();
  }
}
