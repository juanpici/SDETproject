package utils;

import java.io.IOException;
import java.nio.file.*;

public final class EvidenceUtils {
  private EvidenceUtils() {}

  public static String sanitizeName(String name) {
    if (name == null) return "scenario";
    String cleaned = name.replaceAll("[^a-zA-Z0-9\\-_ ]", "");
    cleaned = cleaned.trim().replaceAll("\\s+", "-");
    return cleaned.isBlank() ? "scenario" : cleaned;
  }

  public static Path evidenceDir(String scenarioName) {
    String safe = sanitizeName(scenarioName);
    Path dir = Paths.get("target", "evidence", safe);
    try { Files.createDirectories(dir); }
    catch (IOException e) { throw new RuntimeException("Failed to create evidence dir: " + dir, e); }
    return dir;
  }
}
