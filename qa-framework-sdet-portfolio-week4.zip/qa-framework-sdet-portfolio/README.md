# qa-framework-sdet-portfolio (Week 4 upgrade)

Enterprise-style SDET portfolio framework demonstrating **UI + API automation**, **BDD**, **parallel execution**, **CI**, **Allure reporting**, **Playwright tracing**, **schema validation**, and **metrics**.

## Stack
- Java 17, Maven
- UI: Playwright (Java)
- BDD: Cucumber (JUnit 5 Platform Suite)
- API: RestAssured + JSON Schema Validator
- Reporting: Cucumber HTML/JSON + Allure results
- CI: GitHub Actions

## Quick start
> First run downloads Playwright browsers.

### Run smoke (default)
```bash
mvn test
```

### UI smoke only
```bash
mvn -Dcucumber.filter.tags="@ui and @smoke" test
```

### API smoke only
```bash
mvn -Dcucumber.filter.tags="@api and @smoke" test
```

### Regression
```bash
mvn -Dcucumber.filter.tags="not @wip" test
```

### Environment
```bash
mvn -Denv=qa test
mvn -Denv=staging test
```

## Tags
- `@smoke` quick confidence suite
- `@regression` broader suite
- `@ui` UI tests (Playwright)
- `@api` API tests (RestAssured)
- `@wip` excluded from default execution

## Reporting & evidence
- Cucumber HTML: `target/cucumber-report.html`
- Cucumber JSON: `target/cucumber-report.json`
- Allure results: `target/allure-results`
- Evidence on failure: `target/evidence/<scenario-name>/failure.png` + `page.html` + `trace.zip`

## Metrics
- Scenario duration CSV: `target/metrics/scenario_times.csv`

## Rerun file
- Failed scenarios list: `target/rerun.txt`

## Allure (optional viewing)
If you have Allure CLI installed:
```bash
allure serve target/allure-results
```

## Architecture
- `config/` env config loader
- `drivers/` Playwright lifecycle + ThreadLocal isolation
- `pages/` Page Objects
- `steps/` UI step definitions
- `api/` REST client + API step definitions
- `hooks/` scenario setup/teardown + evidence + trace + metrics
- `schemas/` JSON Schemas for contract-lite validation

## Key decisions
- ThreadLocal BrowserContext/Page for safe parallel execution.
- Playwright tracing always enabled; saved only on failure.
- Schema validation for API to simulate contract testing.
- Metrics CSV for trend tracking (duration + status).
